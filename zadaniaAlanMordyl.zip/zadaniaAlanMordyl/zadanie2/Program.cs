﻿using zadanie2;

P0();

void P0()
{
    Prostokąt kartka = Prostokąt.ArkuszPapieru("A4");

    Console.WriteLine(kartka.BokA);
    Console.WriteLine(kartka.BokB);
}