﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie4
{
    internal class Produkt
    {
        public readonly static string[] kraje =
        {
            "Polska",
            "Szwajcaria",
            "Belgia",
            "Ukraina",
            "Czechy"
        };
        public readonly static Dictionary<string, decimal> stawkiVat = new Dictionary<string, decimal>()
        {
            ["rtv,agd"] = 0.23m,
            ["spożywka"] = 0.23m,
            ["ubrania"] = 0.23m,
            ["części samochodowe"] = 0.08m,
            ["rowery"] = 0.08m,
           
        };

        public string Nazwa = "";
        protected string kategoriaVat = "";
        protected decimal cenaNetto;
        protected decimal cenaBrutto;
        protected string krajPochodzenia = "";

        public virtual string KategoriaVat
        {
            get => kategoriaVat;
            set
            {
                if (stawkiVat.ContainsKey(value))
                    kategoriaVat = value;
            }
        }
        public decimal CenaNetto
        {
            get => cenaNetto;
            set
            {
                if (value > 0)
                    cenaNetto = value;
            }
        }
        public decimal CenaBrutto
        {
            get => cenaNetto * (stawkiVat[kategoriaVat] + 1m);
        }

        public string KrajPochodzenia
        {
            get => krajPochodzenia;
            set
            {
                if (kraje.Contains(value))
                    krajPochodzenia = value;
            }
        }
    }
}
