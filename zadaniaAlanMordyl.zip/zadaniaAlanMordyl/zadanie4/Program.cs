﻿using zadanie4;

P0();

void P0()
{
    Wielopak wielopak = new Wielopak();
    wielopak.Produkt = new Produkt();
    wielopak.Produkt.Nazwa = "toster";
    wielopak.KategoriaVat = "agd";
    wielopak.Ilość = 5;
    wielopak.CenaNetto = 5;

    Console.WriteLine(wielopak.CenaBrutto);
}