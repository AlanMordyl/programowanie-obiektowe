﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zadanie4
{
    internal class ProduktSpożywczy : Produkt
    {
        readonly static string[] stawkiVatSpożywcze =
        {
            "nabiał",
            "mięso",
            "warzywa",
            "owoce",
        };

        readonly static string[] listaAlergenów =
        {
            "gluten",
            "mięczaki",
            "skorupiaki",
            "seler",
            "łubin",
            "jaja",
            "ryby",
        };

        public uint Kalorie;
        private HashSet<string> Alergeny = new HashSet<string>();

        public void Dodaj(string alergen)
        {
            if (Array.Exists(listaAlergenów, element => element == alergen))
                Alergeny.Add(alergen);

        }
        public void Usuń(string alergen)
        {
            Alergeny.Remove(alergen);
        }
        public void Wyświetl()
        {
        foreach (string alergen in Alergeny)
            Console.WriteLine(alergen);
        }
    }
}
