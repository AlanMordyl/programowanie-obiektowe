﻿using zadanie1;

P0();

void P0()
{
    Osoba osoba = new Osoba("Anna Maria Wesołowska");
    osoba.DataUrodzenia = new DateTime(1954, 10, 11);
    osoba.DataŚmierci = new DateTime(2010, 11, 11);

    Console.WriteLine(osoba.Wiek);
}